#ifndef ATV_H
#define ATV_H

#include <stdint.h>

extern const int pal_h;
extern const int pal_v;
extern const int pal_m_h;
extern const int pal_m_v;
extern const int ntsc_h;
extern const int ntsc_v;
extern const int secam_h;
extern const int secam_v;
extern const int nbtv32_h;
extern const int nbtv32_v;
extern const int nbtv32_43_h;
extern const int nbtv32_43_v;
extern const int nbtv64_h;
extern const int nbtv64_v;
extern const int nbtv64_43_h;
extern const int nbtv64_43_v;
extern const int nbtv120_h;
extern const int nbtv120_v;
extern const int nbtv120_43_h;
extern const int nbtv120_43_v;
extern const int nbtv128_h;
extern const int nbtv128_v;
extern const int nbtv128_43_h;
extern const int nbtv128_43_v;
extern const int nbtv240_h;
extern const int nbtv240_v;
extern const int nbtv240_43_h;
extern const int nbtv240_43_v;

enum NbtvMode {
    NBT_1BIT = 1,
    NBT_4BIT = 4,
    NBT_8BIT = 8
};

#endif